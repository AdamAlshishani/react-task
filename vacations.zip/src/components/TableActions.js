import { Button } from "@mui/material";
import React from "react";

export default function TableActions(props) {
  return (
    <div className="tableActions">
      <Button variant="text" onClick={() => {}}>
        Add
      </Button>
      <Button
        variant="text"
        onClick={() => {
          JSON.parse(localStorage.getItem("checkedBoxes")).forEach((id) => {
            return props.handleDeleteVacation(id);
          });
        }}
      >
        Delete
      </Button>
      <Button variant="text">Approve</Button>
      <Button variant="text">Decline</Button>
    </div>
  );
}
