import React, { useEffect, useState } from "react";
import { getVacationsObjectKeys } from "../data/vacations";
import RowCheckbox from "./RowCheckbox";
import StatusTableRow from "./StatusTableRow";

export default function TableBody(props) {
  const [checkList, setCheckList] = useState([]);

  const tableColumns = getVacationsObjectKeys().filter((key) => {
    return !props.excludedColumns.includes(key);
  });

  function handleAddToCheckList(event) {
    var updatedList = [...checkList];
    if (event.target.checked) {
      updatedList = [...checkList, event.target.name];
    } else {
      updatedList.splice(checkList.indexOf(event.target.name), 1);
    }
    setCheckList(updatedList);
  }

  useEffect(() => {
    localStorage.setItem("checkedBoxes", JSON.stringify(checkList));
  }, [checkList]);

  function createTableRow(vacation, column) {
    switch (column) {
      case "status":
        return <StatusTableRow vacation={vacation} column={column} />;
      case "checked":
        return (
          <RowCheckbox
            vacation={vacation}
            column={column}
            handleCheck={handleAddToCheckList}
          />
        );
      case "attachment":
        return (
          <a href={vacation[column]} download>
            Download
          </a>
        );
      default:
        return vacation[column];
    }
  }

  return (
    <tbody>
      {props.filterTable().map((vacation, index) => {
        return (
          <tr>
            {tableColumns.map((column, index) => {
              return <td>{createTableRow(vacation, column)}</td>;
            })}
          </tr>
        );
      })}
    </tbody>
  );
}
