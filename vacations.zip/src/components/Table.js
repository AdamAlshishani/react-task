import React from "react";
import TableBody from "./TableBody";
import TableHead from "./TableHead";

export default function Table(props) {
  return (
    <div>
      <table className="table">
        <TableHead excludedColumns={props.excludedColumns} />
        <TableBody
          excludedColumns={props.excludedColumns}
          filterTable={props.filterTable}
        />
      </table>
    </div>
  );
}
