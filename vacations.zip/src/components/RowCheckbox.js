import React, { useState } from "react";

export default function RowCheckbox(props) {
  return (
    <input type="checkbox" onChange={(e) => props.vacation[props.column]} />
  );
}
