import React from "react";

export default function UserActions() {
  return (
    <div className="userActions">
      <li>Upload New</li>
      <li>My Submissions</li>
      <li>For Approval</li>
    </div>
  );
}
