import React from "react";
import DragDrop from "./DragDrop";
export default function UploadArea() {
  return (
    <div className="uploadArea">
      <DragDrop />
    </div>
  );
}
