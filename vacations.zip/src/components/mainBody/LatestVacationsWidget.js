import React from "react";
import Table from "../Table";
import ViewMoreButton from "../ViewMoreButton";
import { sortVacationsByDate } from "../../data/vacations";

export default function LatestVacationsContainer(props) {
    const latestVacationsExcludedColumns = [
        "attachment",
        "id"
    ];

    return (
        <div className="latestVacationsContainer">
            <h1>Latest Vacations - {new Date().toLocaleDateString("en-GB")}</h1>
            <Table
                excludedColumns={latestVacationsExcludedColumns}
                filterTable={sortVacationsByDate}
            />
            <ViewMoreButton toggleAllVacations={props.toggleAllVacations} />
        </div>
    );
}
