import { Button } from "@mui/material";
import React, { useState } from "react";
import Table from "../Table";
import TableActions from "../TableActions";

export default function AllVacationsContainer(props) {
  function sortVacationsByDate() {
    return props.dataSource.sort((a, b) => {
      return new Date(b.uploadDate) - new Date(a.uploadDate);
    });
  }

  return (
    <div className="allVacationsContainer">
      <div className="row">
        <h1>All Vacations</h1>
        <TableActions handleDeleteVacation={props.handleDeleteVacation} />
      </div>

      <Table filterTable={sortVacationsByDate} excludedColumns={["id"]} />
      <Button
        variant="text"
        onClick={(e) => {
          props.toggleAllVacations();
        }}
      >
        {"<<"}back
      </Button>
    </div>
  );
}
