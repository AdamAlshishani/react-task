import React, { useState } from "react";
import InformationContainer from "./InformationWidget";
import NavigationDropList from "../sideBar/NavigationDropList";
import AllVacationsContainer from "./AllVacationsContainer";
import { getThemeProps } from "@mui/system";

export default function MainBody(props) {
  const [showAllVacations, setshowAllVacations] = useState(false);

  function toggleAllVacations() {
    setshowAllVacations(!showAllVacations);
  }

  return (
    <div className="mainBody">
      <NavigationDropList />
      {showAllVacations ? (
        <AllVacationsContainer
          toggleAllVacations={toggleAllVacations}
          dataSource={props.dataSource}
          handleDeleteVacation={props.handleDeleteVacation}
        />
      ) : (
        <InformationContainer
          toggleAllVacations={toggleAllVacations}
          dataSource={props.dataSource}
        />
      )}
    </div>
  );
}
