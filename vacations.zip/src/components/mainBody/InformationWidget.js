import React from "react";
import UploadArea from "../UploadArea";
import ForApprovalContainer from "./ForApprovalWidget";
import LatestVacationsContainer from "./LatestVacationsWidget";
import MySubmissionsContainer from "./MySubmissionsWidget";

export default function InformationContainer(props) {
  return (
    <div className="informationContainer">
      <div className="col-1">
        <LatestVacationsContainer toggleAllVacations={props.toggleAllVacations} />
        <UploadArea />
      </div>
      <div className="col2">
        <MySubmissionsContainer />
        <ForApprovalContainer />
      </div>
    </div>
  );
}
