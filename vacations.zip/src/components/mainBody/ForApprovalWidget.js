import React, { useState, useEffect } from "react";
import Table from "../Table";
import { getCurrentUSerPendingVacations } from "../../data/vacations";

export default function ForApprovalContainer() {

    const forApprovalExcludedColumns = [
        "id", "uploadDate", "uploaderName", "status"
    ];
    return (
        <div className="forApprovalContainer">
            <h1>For Approval</h1>
            <Table excludedColumns={forApprovalExcludedColumns} filterTable={getCurrentUSerPendingVacations} />
        </div>
    );
}
