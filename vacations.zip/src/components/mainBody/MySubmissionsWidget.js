import React from "react";
import Table from "../Table";
import ViewMoreButton from "../ViewMoreButton";
import { getCurrentUserVacations } from "../../data/vacations";

export default function MySubmissionsContainer() {
    const mySubmissionsExcludedColumns = [
        "id", "uploadDate", "attachment", 'uploaderName'
    ];

    return (
        <div className="mySubmissionsContainer">
            <h1>My Submission</h1>
            <Table excludedColumns={mySubmissionsExcludedColumns} filterTable={getCurrentUserVacations} />
            <ViewMoreButton />
        </div>
    );
}
