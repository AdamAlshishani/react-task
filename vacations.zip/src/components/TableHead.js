import React from "react";
import { getVacationsObjectKeys } from "../data/vacations";

export default function TableHead(props) {
  const tableColumns = getVacationsObjectKeys().filter((key) => {
    return !props.excludedColumns.includes(key);
  });
  return (
    <thead>
      <tr>
        {tableColumns.map((column) => {
          return column === "checked" ? (
            <th></th>
          ) : (
            <th>{column.toUpperCase()}</th>
          );
        })}
      </tr>
    </thead>
  );
}
