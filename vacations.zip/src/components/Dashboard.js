import React, { useState } from "react";
import MainBody from "./mainBody/MainBody";
import NavigationBar from "./topBar/NavigationBar";
import VACATIONS from "../data/vacations";

export default function Dashboard(props) {
  const [vacationsData, setVacationsData] = useState(VACATIONS);
  const [checkedBoxList, setCheckedBoxList] = useState([]);

  function handleDeleteVacation(id) {
    console.log(id);
    setVacationsData(
      checkedBoxList.forEach(
        vacationsData.filter((vacation) => vacation.id != id)
      )
    );
    console.log(vacationsData);
  }

  return (
    <div className="dashboard">
      <NavigationBar
        userName={props.userName}
        handleSignOut={props.handleSignOut}
      />
      <MainBody
        dataSource={vacationsData}
        handleDeleteVacation={handleDeleteVacation}
      />
    </div>
  );
}
