const USERS = [
  { username: "Adam", password: "123123" },
  { username: "Ammar", password: "123123" },
];
